      <div>
        <BottomNavigation
          items={bottomNavItems}
          defaultSelected={0}
          onItemClick={(item) => console.log(item)}
        />
      </div>